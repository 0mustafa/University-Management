-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: universitymanagement
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `tc_no` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `birth` varchar(45) DEFAULT NULL,
  `age` int DEFAULT NULL,
  `school_number` varchar(45) DEFAULT NULL,
  `student_mail` varchar(45) DEFAULT NULL,
  `faculty_id` int DEFAULT NULL,
  `faculty_name` varchar(45) DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `department_name` varchar(45) DEFAULT NULL,
  `score` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (2,'yunus emre','aydemir','5464558468',NULL,'Tue Jan 18 22:21:11 TRT 2022',NULL,'22230600','22230600@ogrenci.edu.tr',23,'mimarlık fakültesi',6,'iç Mimar','355.0'),(12,'mustafa','ozdemir','46846',NULL,'Fri Jan 07 00:00:00 TRT 2022',NULL,'22010100','22010100@ogrenci.edu.tr',1,'mühendislik fakültesi',1,'bilgisayar mühendisliği','450.5'),(13,'bahadır','parlakoğlu','165465',NULL,'Fri Jan 14 23:33:19 TRT 2022',NULL,'22020000','22020000@ogrenci.edu.tr',2,'ziraat fakültesi',22,'kanatlı hayvan yetiştiriciliği','313.1'),(16,'hazal','kaya','45685',NULL,'Wed Jan 19 00:00:00 TRT 2022',NULL,'22281915','22281915@ogrenci.edu.tr',28,'sağlık bilimleri fakültesi',19,'fizyoterapi ve rehabilitasyon','300.0'),(17,'teoman','kara','45868546',NULL,'Thu Jan 13 00:00:00 TRT 2022',NULL,'22302517','22302517@ogrenci.edu.tr',30,'ilahiyat fakültesi',25,'ilahiyat','100.0'),(19,'hasan','yılmaz','12',NULL,'Wed Jan 05 00:00:00 TRT 2022',NULL,'12','22010218@ogrenci.edu.tr',1,'mühendislik fakültesi',2,'makine mühendisliği','400.0'),(20,'ilyas','turalı','16846',NULL,'Thu Jan 20 14:04:48 TRT 2022',NULL,'22010120','22010120@ogrenci.edu.tr',1,'mühendislik fakültesi',1,'bilgisayar mühendisliği','400.0'),(21,'temel','çıray','12345678910',NULL,'Wed Jan 26 18:50:40 TRT 2022',NULL,'22010221','22010221@ogrenci.edu.tr',1,'mühendislik fakültesi',2,'makine mühendisliği','350.0'),(22,'muammer','öztürk','12345678910',NULL,'Mon Jul 14 21:24:40 TRST 2003',NULL,'22261122','22261122@ogrenci.edu.tr',26,'diş hekimliği fakültesi',11,'ortodonti','480.0'),(23,'hüma','pak','14725836914',NULL,'Thu Jan 20 21:47:56 TRT 2022',NULL,'22242023','22242023@ogrenci.edu.tr',24,'güzel sanatlar fakültesi',20,'gazetecilik','280.0'),(24,'dgdssfgssfvdf','rtgbbvfsd','12345678910',NULL,'Sat Jan 08 20:47:53 TRT 2022',NULL,'22010124','22010124@ogrenci.edu.tr',1,'mühendislik fakültesi',1,'bilgisayar mühendisliği','400.0');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-24 22:38:09
