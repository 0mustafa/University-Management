-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: universitymanagement
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lesson_student`
--

DROP TABLE IF EXISTS `lesson_student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lesson_student` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int DEFAULT NULL,
  `student_first_name` varchar(45) DEFAULT NULL,
  `student_last_name` varchar(45) DEFAULT NULL,
  `lesson_id` int DEFAULT NULL,
  `lesson_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lesson_student`
--

LOCK TABLES `lesson_student` WRITE;
/*!40000 ALTER TABLE `lesson_student` DISABLE KEYS */;
INSERT INTO `lesson_student` VALUES (7,1,'enes','yılmaz',8,'mukavemet'),(8,2,'mustafa','özdemir',7,'akışkanlar mekaniği'),(9,6,'temel','çıray',6,'termodinamik'),(10,16,'hazal','kaya',17,'genel kimya'),(11,16,'hazal','kaya',15,'fizik 1'),(12,16,'hazal','kaya',18,'anatomi'),(13,16,'hazal','kaya',24,'mitoloji'),(20,19,'hasan','yılmaz',25,'bilgisayar mühendisliğine giriş'),(22,20,'ilyas','turalı',26,'deneme'),(23,20,'ilyas','turalı',27,'deneme ders'),(24,22,'muammer','öztürk',28,'biyokimya'),(25,22,'muammer','öztürk',29,'biyofizik'),(26,22,'muammer','öztürk',30,'organik kimya'),(59,12,'mustafa','ozdemir',2,'ayrık matematik'),(60,12,'mustafa','ozdemir',24,'mitoloji'),(62,12,'mustafa','ozdemir',5,'veri yapıları'),(63,12,'mustafa','ozdemir',22,'sayısal elektronik'),(64,12,'mustafa','ozdemir',25,'bilgisayar mühendisliğine giriş'),(66,12,'mustafa','ozdemir',16,'fizik 2');
/*!40000 ALTER TABLE `lesson_student` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-24 22:38:09
