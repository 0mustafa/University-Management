-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: universitymanagement
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `instructors`
--

DROP TABLE IF EXISTS `instructors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `degree` varchar(45) DEFAULT NULL,
  `tc_no` varchar(11) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `birth` date DEFAULT NULL,
  `age` int DEFAULT NULL,
  `mail` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `faculty_id` int DEFAULT NULL,
  `faculty_name` varchar(45) DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `department_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructors`
--

LOCK TABLES `instructors` WRITE;
/*!40000 ALTER TABLE `instructors` DISABLE KEYS */;
INSERT INTO `instructors` VALUES (31,'enes','yilmaz','doktor','12345678910',NULL,NULL,NULL,'enes.yilmaz@edu.tr','12345678910',22,'fen edebiyat fakültesi',NULL,'Fizik'),(32,'ilyas','turalı','doktor','12345678910',NULL,NULL,NULL,'ilyas.turalı@edu.tr','12345678910',1,'mühendislik fakültesi',NULL,'makine mühendisliği'),(36,'sami','çakaloğlu','Dekan','12345678910',NULL,NULL,NULL,'sami.çakaloğlu@edu.tr','12345678910',28,'sağlık bilimleri fakültesi',19,'fizyoterapi ve rehabilitasyon'),(39,'mustafa','özdemir','doktor','12345678910',NULL,NULL,NULL,'mustafa.özdemir@edu.tr','12345678910',22,'fen edebiyat fakültesi',31,'matematik'),(43,'temel','çıray','öğretim görevlisi','12345678910',NULL,NULL,NULL,'temel.çıray@edu.tr','12345678910',1,'mühendislik fakültesi',2,'makine mühendisliği'),(44,'fedai','öztürk','doktor','12346578910',NULL,NULL,NULL,'fedai.öztürk@edu.tr','12346578910',26,'diş hekimliği fakültesi',10,'endodonti'),(48,'muammer','öztürk','doktor','12345678910',NULL,NULL,NULL,'muammer.öztürk@edu.tr','12345678910',26,'diş hekimliği fakültesi',11,'ortodonti'),(49,'mustafa','sdfsd','dgbq','12345678910',NULL,NULL,NULL,'mustafa.sdfsd@edu.tr','12345678910',22,'fen edebiyat fakültesi',4,'Biyoloji');
/*!40000 ALTER TABLE `instructors` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-24 22:38:09
